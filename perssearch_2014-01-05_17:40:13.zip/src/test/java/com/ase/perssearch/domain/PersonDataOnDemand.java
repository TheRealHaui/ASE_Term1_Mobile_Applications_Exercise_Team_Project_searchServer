package com.ase.perssearch.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Person.class)
public class PersonDataOnDemand {
}
