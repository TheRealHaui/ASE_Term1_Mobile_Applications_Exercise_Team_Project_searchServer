package com.ase.perssearch.domain.converter;
import com.ase.perssearch.domain.Person;
import org.springframework.roo.addon.jsf.converter.RooJsfConverter;

@RooJsfConverter(entity = Person.class)
public class PersonConverter {
}
